/*  * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*         SENAC - TADS - Programacao Web *
*     ADO #02 Trabalhando As Rotas e LINKS *
* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*     Nome : <<   Robson Gleidson    > > 
* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

import RoutesApp from './route';

function App() {
  return (
    <RoutesApp/>
  );
}

export default App;
